package stringclass;

public class B3Buffer {

	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer("jeevan");
		System.out.println(sb);
		System.out.println(sb.append(" jagan"));
		System.out.println(sb);
		
	}

}
